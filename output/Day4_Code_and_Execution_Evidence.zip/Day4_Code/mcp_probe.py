import asyncio,json,sys
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
from agent_lab import PEOPLE
async def probe():
 params=StdioServerParameters(command=sys.executable,args=[str(Path(__file__).with_name('mcp_server.py'))])
 eid=next(p['employee_id'] for p in PEOPLE.values() if (p['tenant'],p['department'])==('org-a','finance'))
 other=next(p['employee_id'] for p in PEOPLE.values() if p['tenant']!='org-a')
 async with stdio_client(params) as (read,write):
  async with ClientSession(read,write) as s:
   await s.initialize();tools=await s.list_tools();resources=await s.list_resources();prompts=await s.list_prompts()
   ok=await s.call_tool('get_employee',{'employee_id':eid})
   denied=await s.call_tool('get_employee',{'employee_id':other})
   invalid=await s.call_tool('get_department_context',{'department':'legal'})
   return dict(tools=len(tools.tools),resources=len(resources.resources),prompts=len(prompts.prompts),read_success=not ok.isError,cross_tenant_rejected=bool(denied.isError),invalid_department_rejected=bool(invalid.isError),success_response=ok.model_dump(mode='json'),denied_response=denied.model_dump(mode='json'),invalid_response=invalid.model_dump(mode='json'))
if __name__=='__main__':print(json.dumps(asyncio.run(probe()),ensure_ascii=False))
