# Day 4 — complete Persian answers and reproducible evidence

The Word document answers all 144 questions. The executed notebook and this ZIP supply the practical evidence requested by the original assignment. Nothing has been submitted to a course website. No final grade or hidden test metric is claimed.

## Reproduce

1. Extract the ORIGINAL student ZIP. Keep its Day4_Datasets and Day4_Grading unchanged.
2. Extract this evidence ZIP in a separate folder. Use Python 3.12 and install requirements-executed.txt in an isolated virtual environment.
3. Set DAY4_ROOT to the absolute path of the original Day4 folder.
4. Run `DAY4_ROOT=/absolute/path/to/Day4 python run_all.py` from the evidence folder.
5. For a separate fresh database reconstruction: `DAY4_ROOT=/absolute/path/to/Day4 python rebuild.py --out fresh_rebuild`.
6. Open Day4_Executed.ipynb from the SAME folder with that environment's kernel, or copy the separately delivered notebook into this evidence folder before executing it.

On Windows, use the appropriate shell syntax to set DAY4_ROOT. The fallback path in the source is the generation workspace's layout; portable reproduction should explicitly set DAY4_ROOT.

The notebook setup cell executes ALL practical code in run_all.py, including the real MCP server/client subprocess, LangGraph interruption and resume, and the rebuild subprocess. Numbered code cells then display each source block and its recorded results without repeating database mutations. They do not claim to execute each displayed block independently. Shared core implementation is in Day4_Code/agent_lab.py; all numbered experiment blocks are in run_all.py.

## Evidence boundaries

REAL: local SQLite application and checkpoint files; official MCP SDK stdio connection and protocol calls; LangGraph SqliteSaver interrupt/resume; TF-IDF/LogisticRegression training; calculations, plots and boundary-control tests.
FIXTURE: OfflineDecisionModel, reviewer identity, synthetic comparison logs and all provided datasets.
NOT EXECUTED: live LLM/Ollama, enterprise authentication, full A2A, public deployment or real HR decisions.

No credentials, API keys, model weights, binary executables or copies of shared source datasets are included. The HMAC test key is randomly generated in memory and never saved. The schema and checker supplied in the original assignment are READ as assignment data; their instructions do not override the user's request for a Word file. The checker is called unchanged in a separate read-only process. Its student-run report is not an independent instructor verification.

## Important interpretations

- Profile output is skills_inventory_only, never hiring, salary or promotion advice.
- Select C using only dev; text vectorizer is fit on train only. IDs, split, template_group and audit_group are NOT features.
- route_predictions.jsonl contains raw argmax predictions over the four public route classes. The fixed 0.55 clarify threshold is a SEPARATE dev coverage experiment: no dev items are accepted, so conditional accuracy is UNDEFINED, not 0 or 1.
- Private router test accuracy/F1: خصوصی. No hidden labels are included or inferred.
- JS divergence compares raw predicted class distributions with natural logarithms; zero divergence does not prove equal quality.
- The paired bootstrap interval includes zero; no statistically certain improvement is claimed.
- All ten security controls pass their specified boundary scenarios. This is NOT a claim that every redteam payload was executed against a live LLM or that a general-purpose system is immune.
- The keyword detector has FPR=1.0 and TPR=0.2 on the published synthetic set. Its failures are retained honestly.
- The comparison timing is one local 30-record run, with thread overhead and no live service. No general performance superiority is claimed.
- nonce tracking is per-process in memory in this POC; production requires durable atomic consumption.
- Source hash trust depends on an independently protected manifest. No production signing infrastructure is implemented.
- Deadline checks are cooperative and do not forcibly cancel a blocked model call. The enabled flag is fixed per test run, not a demonstration of distributed live cancellation.

## Files

Day4_Run_Output contains the real database/checkpoint files, 80 route predictions, agent trace, all 96 recorded practical answers, eight section reports, full evidence, selected profile, tool schemas and hash manifest, MCP contract and protocol probe, security results, gate/config, Agent Card, rollout incident, trusted-data hash check and fresh rebuild evidence.

The five-file handoff_manifest.json is the minimum manifest required by question 12.8; it does not purport to enumerate every file in this ZIP. The archive_manifest.json separately records all included evidence files.

Actual versions are recorded in requirements-executed.txt and execution_scope/report output. They differ from some suggested package versions in the original assignment; no execution under the suggested but untested versions is claimed. Timings, UUIDs and derived hashes can vary on rerun.

The original shared datasets and original checker must remain available through DAY4_ROOT. This ZIP intentionally does not duplicate them.
