from pathlib import Path
import json,re,sys,os,textwrap,zipfile,hashlib,importlib.metadata
BASE=Path(__file__).resolve().parent
DATA_ROOT=BASE.parent/'pack'/'Day4'
R=json.loads((BASE/'Day4_Run_Output/answers_practical.json').read_text())
S=json.loads((DATA_ROOT/'Day4_Grading/question_schema.json').read_text())
concept={};analysis={}
for line in (BASE/'conceptual.txt').read_text().splitlines():
 q,option,why=line.split('|',2);concept[q]={'option':option,'analysis':why}
for line in (BASE/'practical.txt').read_text().splitlines():
 q,method,why=line.split('|',2);analysis[q]={'method':method,'analysis':why}
source=(BASE/'run_all.py').read_text();blocks={}
markers=list(re.finditer(r'^# Q (\d+\.\d+)\s*$',source,re.M))
for i,m in enumerate(markers):blocks[m[1]]=source[m.end():markers[i+1].start() if i+1<len(markers) else source.index('# Normalize tuples')].strip()
def direct(q):
 r=R[q];V=lambda *keys:[r[k] for k in keys]
 maps={
 '5.1':['people','policies','documents','split_sizes'],'5.2':['allowed_documents','scope_isolated'],'5.3':['selected','input_used','input_remaining'],'5.4':['insufficient_budget_rejected'],'5.5':['retrieved_count','zero_limit_rejected'],'5.6':['email_removed','work_text_preserved'],'5.7':['before_count','after_count','character_reduction'],'5.8':['references_retained','json_character_reduction'],'5.9':['minimal_policy_context','evidence_read_only'],'5.10':['claim_count','decision'],'5.11':['tampered_quote_rejected','fake_reference_rejected'],'5.12':['mean_coverage','department_means'],
 '6.1':['employee_required','policy_required','extra_fields_forbidden'],'6.2':['successful_calls','email_removed','evidence_count'],'6.3':['rejected_inputs','tests'],'6.4':['cross_tenant_rejected','cross_department_rejected'],'6.5':['mcp_tools','transport'],'6.6':['discovered_tools','resources','prompts','read_success'],'6.7':['mcp_cross_tenant_rejected','mcp_invalid_department_rejected'],'6.8':['scope_retryable','error_fields'],'6.9':['valid_structural','invalid'],'6.10':['hash_changed','hex_length'],'6.11':['live_llm_reference','executed_model'],'6.12':['forbidden_capabilities','a2a_complete'],
 '7.1':['accepted','rejected'],'7.2':['status','trace_steps','tool_order'],'7.3':['stop_reason','actual_tool_calls'],'7.4':['stop_reason','actual_tool_calls','final_exists'],'7.5':['stop_reason','actual_tool_calls','estimated_cost'],'7.6':['stop_reason','tools_after_deadline'],'7.7':['attempts','wait_ms','status'],'7.8':['attempts','status'],'7.9':['rejected_runs','malicious_successful_tools'],'7.10':['out_of_scope_decision_rejected','free_text_proves_success'],'7.11':['trajectory_valid','trace_steps'],'7.12':['normal_accepted','kill_blocks_tools'],
 '8.1':['real_connection','application_tables','foreign_keys'],'8.2':['day29','day30'],'8.3':['persistent','returned_records'],'8.4':['poisoned_memory_rejected'],'8.5':['cross_tenant_memory_rejected'],'8.6':['candidate_events','unverified_total','candidate_types'],'8.7':['deleted','remaining'],'8.8':['pending','version_before'],'8.9':['committed','version','audit_events'],'8.10':['version_after_replay','audit_after_replay','changed_body_same_key_rejected'],'8.11':['stale_approval_rejected','changed_payload_rejected'],'8.12':['human_rejection_recorded','rejected_employee_version','approved_employee_version'],
 '9.1':['public_labels','unlabeled_test','groups_disjoint'],'9.2':['majority_macro_f1','router_macro_f1'],'9.3':['selected_C','selected_dev_macro_f1'],'9.4':['dev_coverage','conditional_accuracy','clarify_count'],'9.5':['reports_created','gate_stops'],'9.6':['workers','claims','same_as_single'],'9.7':['worker_distribution','max_workers'],'9.8':['evaluations','finally_accepted'],'9.9':['valid_message_accepted','invalid_rejected'],'9.10':['valid_profile_passed','tampered_profile_rejected','worker_has_write'],'9.11':['normal_status','cycle_status'],'9.12':['all_outputs_equal','sequential_ms','parallel_ms','parallel_over_sequential'],
 '10.1':['malicious','benign','malicious_families'],'10.2':['TPR','FPR'],'10.3':['goal_hijack_blocked'],'10.4':['external_send_blocked'],'10.5':['privilege_abuse_blocked'],'10.6':['tamper_detected'],'10.7':['untrusted_code_blocked'],'10.8':['poison_rejected_without_change'],'10.9':['first_accepted','replay_rejected','forgery_rejected'],'10.10':['status','commit_allowed'],'10.11':['post_approval_change_rejected','audit_unchanged'],'10.12':['families_tested','successful_controls'],
 '11.1':['runs','scenarios','spans','paired'],'11.2':['baseline_success','candidate_success','candidate_violation'],'11.3':['test_predictions','complete_unique_coverage','route_distribution'],'11.4':['mean_difference','ci95_lower','ci95_upper','test_pairs'],'11.5':['wall_P50_ms','wall_P95_ms','duration_mismatches','runs_work_exceeds_wall'],'11.6':['total_cost_usd','candidate_cost_per_success_usd'],'11.7':['call_weighted_accuracy','mean_run_accuracy'],'11.8':['success_with_violation','safe_success_rate','raw_success_rate'],'11.9':['baseline_edit_rate','candidate_edit_rate'],'11.10':['groups','success_gap'],'11.11':['JS_divergence','natural_log_upper_bound'],'11.12':['successful_checks','quality_checks'],
 '12.1':['quality','policy','latency','allowed'],'12.2':['canary_requests','total_requests','observed_fraction','feature_flag_respected'],'12.3':['shadow_completed','profiles_unchanged'],'12.4':['new_jobs','duplicate_deliveries','unique_events'],'12.5':['status','checks','passed'],'12.6':['status','passed'],'12.7':['required_fields','complete'],'12.8':['manifest_file_count','hash_structure_valid'],'12.9':['trusted_questions','trusted_total_points','fake_999_discarded'],'12.10':['real_components','live_llm_executed'],'12.11':['new_tools','loop_status','next_mode'],'12.12':['all_data_hashes_match','security_controls_passed','database_checker_passed','practical_answers','test_predictions']}
 return V(*maps[q])

def textval(x):
 if x is True:return 'بله'
 if x is False:return 'خیر'
 if x is None:return 'تعریف‌نشده؛ هیچ نمونه‌ای پذیرفته نشده است.'
 if isinstance(x,float):return f'{x:.10g}'
 if isinstance(x,dict):return '؛ '.join(f'{k}: {textval(v)}' for k,v in x.items())
 if isinstance(x,list):return '، '.join(map(textval,x))
 return str(x)
# Validate full question coverage and direct field alignment before writing artifacts.
assert len(concept)==48 and len(analysis)==96 and len(R)==96
for section in S:
 for q in section['questions']:
  qid=q['id']
  if int(qid.split('.')[0])<5:assert concept[qid]['option'] in q['fields'][0]['options']
  else:
   fields=[f for f in q['fields'] if f['label']!='روش اجرا و تحلیل']
   assert len(fields)==len(direct(qid)),(qid,len(fields),len(direct(qid)))
OUT=Path(os.environ.get('DELIVERABLE_OUTPUT',str(BASE.parent.parent/'output')))
OUT.mkdir(exist_ok=True,parents=True)
# DOCX with explicit right-to-left paragraphs, tables and Persian language metadata.
from docx import Document
from docx.shared import Inches,Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
D=Document();sec=D.sections[0];sec.page_height=Cm(29.7);sec.page_width=Cm(21);sec.top_margin=Cm(1.8);sec.bottom_margin=Cm(1.8);sec.left_margin=Cm(1.8);sec.right_margin=Cm(1.8)
sec.header_distance=Cm(.7);sec.footer_distance=Cm(.7)
styles=D.styles
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
 st=styles[name];st.font.name='Arial';st.font.size=Pt(11 if name=='Normal' else {'Title':27,'Subtitle':14,'Heading 1':18,'Heading 2':14,'Heading 3':11}[name]);st.paragraph_format.space_after=Pt(6);st.paragraph_format.line_spacing=1.25
 rpr=st.element.get_or_add_rPr();fonts=rpr.rFonts
 if fonts is not None:fonts.set(qn('w:cs'),'Arial')
 lang=OxmlElement('w:lang');lang.set(qn('w:val'),'fa-IR');lang.set(qn('w:bidi'),'fa-IR');rpr.append(lang)
for name in ['Heading 1','Heading 2','Heading 3']:
 styles[name].font.color.rgb=RGBColor.from_string('15576B');styles[name].paragraph_format.keep_with_next=True
styles['Normal'].paragraph_format.widow_control=True

def rtl(p):
 p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
 pr=p._p.get_or_add_pPr();b=OxmlElement('w:bidi');b.set(qn('w:val'),'1');pr.append(b)
 return p

def para(text='',style=None,bold=False):
 p=rtl(D.add_paragraph(style=style));r=p.add_run(text);r.bold=bold
 return p

def h(text,level=1):return rtl(D.add_heading(text,level))
def code(text):
 p=D.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT
 pr=p._p.get_or_add_pPr();b=OxmlElement('w:bidi');b.set(qn('w:val'),'0');pr.append(b)
 shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'F1F5F8');pr.append(shade)
 p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_after=Pt(7);p.paragraph_format.keep_together=False
 r=p.add_run(text);r.font.name='Consolas';r.font.size=Pt(8);rpr=r._r.get_or_add_rPr();rr=OxmlElement('w:rtl');rr.set(qn('w:val'),'0');rpr.append(rr)
 return p

def table(rows,heads=None):
 t=D.add_table(rows=0,cols=2);t.style='Light Shading Accent 1';t.alignment=WD_TABLE_ALIGNMENT.CENTER
 bidi=OxmlElement('w:bidiVisual');t._tbl.tblPr.append(bidi)
 if heads:rows=[heads]+list(rows)
 for i,(a,b) in enumerate(rows):
  cells=t.add_row().cells
  for j,value in enumerate([a,b]):
   cells[j].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   p=rtl(cells[j].paragraphs[0]);run=p.add_run(textval(value));run.font.size=Pt(10)
   if heads and i==0:run.bold=True
  trpr=cells[0]._tc.getparent().get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
 return t

header=sec.header.paragraphs[0];rtl(header);header.add_run('روز چهارم | معماری ایجنت، شواهد و کنترل اجرا').font.size=Pt(9)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER
f.add_run('صفحه ').font.size=Pt(9);fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');f._p.append(fld)
D.core_properties.title='پاسخ تشریحی کامل تکلیف روز چهارم — ۱۴۴ زیرسؤال'
D.core_properties.subject='معماری ایجنت و Workflow، MCP، حافظه، ارزیابی و انتشار کنترل‌شده'
D.core_properties.author='';D.core_properties.keywords='Persian, Agent, MCP, LangGraph, SQLite, Day4'
para('پاسخ تشریحی و مستند',style='Title');para('تکلیف روز چهارم',style='Title');para('معماری ایجنت، مهندسی context، ابزارهای محدود و انتشار کنترل‌شده',style='Subtitle')
para('پوشش کامل ۱۲ بخش و ۱۴۴ زیرسؤال',bold=True)
para('۴۸ پاسخ مفهومی + ۹۶ پاسخ عملی | همراه با کد، خروجی واقعی، تحلیل و محدودیت‌های استنباط')
para('تاریخ تدوین: ۲۰ اکتبر ۲۰۲۶')
para('مبنای پاسخ، بستهٔ day4-student-pack.zip و متن تکلیف پیوست‌شده است. همهٔ داده‌های افراد، رخدادها، حمله‌ها و قیمت‌ها در این بسته مصنوعی‌اند. نام، شمارهٔ دانشجویی یا مشخصات پروژهٔ قبلی از سوی کاربر در این گفتگو ارائه نشده و به گزارش افزوده نشده است.')
table([('درخواست تحویلی','فایل Word کامل؛ نوت‌بوک و ZIP شواهد به‌عنوان پیوست بازتولید'),('اجرای واقعی','SQLite، MCP با stdio و LangGraph با checkpoint پایدار'),('fixture','تصمیم‌گیر آفلاین، هویت reviewer و لاگ‌های مقایسهٔ نسخه‌ها'),('اجرا نشده','LLM زنده، A2A کامل، احراز هویت سازمانی و استقرار عمومی'),('معیار خصوصی test مسیریاب','خصوصی؛ پاسخ مخفی در بستهٔ دانشجو وجود ندارد')])
D.add_page_break();h('راهنمای خواندن و مرز شواهد')
para('برای هر زیرسؤال، صورت سؤال اصلی، پاسخ مستقیم و توضیح علمی آمده است. پاسخ‌های عملی علاوه بر روش و تفسیر، قطعهٔ کد انگلیسی و خروجی همان اجرای گزارش‌شده را دارند. توابع مشترک در پیوست کد و ZIP شواهد قرار دارند؛ قطعه‌کدهای هر سؤال با اتکا به همان توابع خوانده می‌شوند.')
para('نتایج نقطه‌ای به اندازهٔ نمایش جدول گرد شده‌اند؛ JSON خروجی جزئیات بیشتری حفظ می‌کند. اعداد وابسته به دستگاه، مانند زمان موازی‌سازی، در بازاجرا تغییر می‌کنند. hash خروجی‌ها هم در صورت تغییر شناسه‌ها یا زمان‌ها می‌تواند عوض شود. بازتولید معتبر یعنی حفظ قرارداد و نتیجهٔ منطقی، نه الزاماً یکسانی بایت‌به‌بایت همهٔ فایل‌ها.')
para('در متن فایل راهنمای بسته آمده است که Word قالب رسمی ارسال این نسخه نیست. این پاسخ مطابق درخواست صریح کاربر به شکل Word تهیه شده و برای سازگاری با شیوهٔ تحویل آموزشی، نوت‌بوک اجراشده و ZIP شواهد هم فراهم شده‌اند. هیچ ارسال به سامانهٔ درس یا ادعای نمرهٔ نهایی انجام نشده است.')
para('اسلایدهای اصلی جلسه در پیوست موجود نیستند. نام‌گذاری‌های L0 و L1/L4 بر اساس خود صورت سؤال و گزینه‌های آن تفسیر شده‌اند و نقل‌قول مستقیمی از اسلاید دیده‌نشده ارائه نشده است.')
h('فهرست بخش‌ها',2)
for section in S:para(f"بخش {section['number']}: {section['title']} — ۱۲ زیرسؤال")
para('پس از بخش‌ها: جدول تهدیدها، واژه‌نامه و فرمول‌ها، کد مشترک اجرایی، منابع روش‌شناسی و راهنمای بازاجرا.')
h('یافته‌های کلیدی و نحوهٔ تفسیر',2)
table([('کیفیت artifact پایگاه','checker: ۱۴ از ۱۴؛ بازسازی تازه: ۱۴ از ۱۴'),('امنیت مرزی','ده سناریوی کنترل‌شده موفق؛ اثبات مصونیت عمومی نیست'),('مسیریاب','C=0.1، macro-F1 روی dev ≈ 0.9365؛ معیار test خصوصی'),('پوشش در آستانهٔ ۰٫۵۵','صفر؛ accuracy شرطی تعریف‌نشده'),('آشکارساز واژه‌ای','TPR=0.2 و FPR=1.0؛ جای کنترل ابزار را نمی‌گیرد'),('مقایسهٔ نسخه‌ها روی test fixture','اختلاف 0.0625؛ CI95=[−0.01875,0.14375] شامل صفر'),('کنترل rollout','فقط محلی و مصنوعی؛ انتشار عمومی انجام نشده')])
for section in S:
 D.add_page_break();num=section['number'];h(f"بخش {num} — {section['title']}")
 para(section['intro']);para('منبع مسئله: '+section['dataset'])
 for q in section['questions']:
  qid=q['id'];h('زیرسؤال '+qid,2);para(q['prompt'])
  if num<5:
   c=concept[qid];idx=q['fields'][0]['options'].index(c['option'])+1
   table([('گزینهٔ منتخب',c['option']),('جایگاه در گزینه‌های صورت سؤال',idx)])
   para('دلیل انتخاب و تفسیر',bold=True);para(c['analysis'])
   code("answer = "+json.dumps({'question_id':qid,'selected_option_index':idx,'selected_option':c['option']},ensure_ascii=False,indent=2)+"\n# Index is the 1-based order in this assignment, not an official answer code.")
  else:
   fields=[f['label'] for f in q['fields'] if f['label']!='روش اجرا و تحلیل'];values=direct(qid)
   table(list(zip(fields,values)),heads=['فیلد پاسخ','نتیجهٔ اجرا'])
   para('روش اجرا',bold=True);para(analysis[qid]['method'])
   para('کد مرتبط با زیرسؤال',bold=True);code(blocks[qid])
   para('خروجی ثبت‌شدهٔ همان اجرا',bold=True);code(json.dumps(R[qid],ensure_ascii=False,indent=2))
   para('تحلیل علمی و محدودیت نتیجه',bold=True);para(analysis[qid]['analysis'])
   images={'5.12':('coverage.png','شکل ۱ — میانگین پوشش شواهد معتبر بر حسب دپارتمان؛ این شاخص نمرهٔ استخدام نیست.'),'10.2':('detector_confusion.png','شکل ۲ — ماتریس خطای detector واژه‌ای؛ سطر، واقعیت و ستون، پیش‌بینی است.'),'11.2':('dev_comparison.png','شکل ۳ — success و policy_violation روی dev برای دو نسخهٔ fixture.')}
   if qid in images:
    name,caption=images[qid];p=D.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run().add_picture(str(BASE/'Day4_Run_Output'/name),width=Cm(15));para(caption)
D.add_page_break();h('پیوست الف — مدل تهدید و مرزهای اعتماد')
para('این جدول دارایی و کنترل اصلی هر خانواده را روشن می‌کند. هر کنترل در سناریوی مصنوعی مربوط آزموده شده است. نتیجهٔ موفق به همان شرایط آزمون محدود است.')
threats=[('Goal hijack','دارایی: صحت هدف و ادعا؛ مرز: سند/مدل به خروجی؛ کنترل: decision محدود و grounding.'),('Tool misuse','دارایی: محرمانگی پرونده؛ مرز: پیشنهاد مدل به capability؛ کنترل: نبود ابزار ارسال بیرونی.'),('Privilege abuse','دارایی: دادهٔ tenant و دپارتمان؛ مرز: آرگومان به هویت؛ کنترل: principal معتبر و scope سمت سرور.'),('Supply chain','دارایی: منبع ابزار؛ مرز: فایل ورودی به کد بارگذاری‌شده؛ کنترل: hash manifest مورد اعتماد قبل از load.'),('Unexpected code execution','دارایی: محیط اجرا؛ مرز: رشتهٔ ورودی به مفسر؛ کنترل: allowlist و نبود eval/exec دادهٔ نامطمئن.'),('Memory poisoning','دارایی: حافظهٔ نشست‌های آینده؛ مرز: داده به دانش پایدار؛ کنترل: verified، تطبیق متن، TTL و scope.'),('Forged messages / Replay','دارایی: هماهنگی نقش‌ها؛ مرز: پیام به اقدام نقش مقصد؛ کنترل: HMAC، مقصد، انقضا و nonce.'),('Cascading failure','دارایی: صحت گزارش تجمیعی؛ مرز: worker به coordinator؛ کنترل: partial، ارجاع و بستن commit.'),('Approval deception','دارایی: اختیار نوشتن حساس؛ مرز: approval به payload؛ کنترل: hash کامل و base_version در تراکنش.'),('Rogue agent','دارایی: بودجه و کنترل سامانه؛ مرز: حلقه به اثر ابزار؛ کنترل: kill switch و سقف قدم پیش از اجرا.')]
table(threats,heads=['خانواده','دارایی، مرز و دفاع'])
h('محدودیت‌های امنیتی POC',2)
para('nonce مصرف‌شده در آزمایش پیام حافظه‌ای است و برای تولید باید پایدار و اتمیک شود. manifest محلی بدون ریشهٔ اعتماد بیرونی از تغییر هم‌زمان فایل و manifest جلوگیری نمی‌کند. principal و reviewer fixture هستند. deadline تعاونی فراخوانی درحال اجرا را لغو نمی‌کند. پرچم enabled در هر اجرای آزمایش ثابت است و برای kill زنده باید پیش از هر اثر از منبع به‌روز خوانده شود. هیچ‌یک از این محدودیت‌ها با موفقیت ده آزمون مرزی از بین نمی‌رود.')
D.add_page_break();h('پیوست ب — فرمول‌ها و قراردادهای اندازه‌گیری')
formulas=[('بودجهٔ ورودی','input_capacity = context_window − reserved_output'),('صرفه‌جویی حجم','reduction = 1 − size_after / size_before'),('پوشش شواهد','coverage(person) = |distinct verified allowed skills| / 4'),('Macro-F1','mean of class F1; F1 = 2TP / (2TP + FP + FN)'),('پوشش مسیریاب','coverage = accepted_dev / total_dev'),('دقت شرطی','conditional_accuracy = correct_accepted / accepted; undefined if accepted=0'),('زمان و کار','wall = max(end) − min(start); work = sum(end − start)'),('هزینهٔ دلار','cost = (input_tokens × input_price + output_tokens × output_price) / 1e6'),('دقت ابزار وزن‌دار','sum(correct_calls) / sum(tool_calls)'),('موفقیت مسیر مجاز','safe_success = success AND NOT policy_violation'),('Jensen–Shannon','M=(P+Q)/2; JSD=0.5 KL(P||M)+0.5 KL(Q||M); 0≤JSD≤ln(2)'),('اختلاف جفت‌شده','d_i = success_candidate,i − success_baseline,i; resample complete pairs'),('نسخهٔ معتبر','approval.base_version = current_version; committed_version = current_version+1')]
table(formulas,heads=['معیار','تعریف'])
para('درصد و نسبت از هم تفکیک شده‌اند: مثلاً ۰٫۰۶۲۵ معادل ۶٫۲۵ واحد درصد اختلاف نرخ موفقیت است، نه الزاماً ۶٫۲۵ درصد رشد نسبی. صدک‌ها با interpolation خطی NumPy محاسبه شده‌اند. لگاریتم JSD طبیعی و smoothing پیش از نرمال‌سازی روی شمار کلاس‌ها افزوده شده است.')
h('پیوست ج — کد مشترک قابل بازاجرا')
para('کدهای زیر توابعی را تعریف می‌کنند که قطعه‌کدهای هر زیرسؤال فراخوانی کرده‌اند. فایل run_all.py شامل آماده‌سازی مشترک، بلوک‌های شماره‌دار همهٔ ۹۶ سؤال و تولید گزارش‌هاست و نسخهٔ کامل آن در ZIP آمده است. دستور بازاجرا در پیوست پایانی درج شده است.')
for name in ['Day4_Code/agent_lab.py','Day4_Code/mcp_server.py','Day4_Code/mcp_probe.py','rebuild.py']:
 h(name,2)
 # Break long listings into short paragraphs to keep pagination stable.
 lines=(BASE/name).read_text().splitlines()
 for i in range(0,len(lines),38):code('\n'.join(lines[i:i+38]))
D.add_page_break();h('پیوست د — منابع و قابلیت بازتولید')
para('اعداد این گزارش از اجرای کد روی بستهٔ پیوست به دست آمده‌اند. منابع زیر مبنای صورت مسئله و روش‌ها هستند؛ برای اسلایدهایی که خودشان در پیوست نیستند نقل‌قول یا شماره‌گذاری تازه ساخته نشده است.')
refs=[('منبع داده و سؤال','day4-student-pack.zip: ASSIGNMENT.md، START_HERE.md، Day4_Datasets/README.md، manifest.json و question_schema.json؛ متن تکلیف پیوست‌شده نیز بررسی شد.'),('قرارداد پایگاه و تصحیح','Day4_Grading/README.md و check_submission.py همراه بسته؛ نسخهٔ مدرس برای تصحیح نهایی مستقل لازم است.'),('MCP Python SDK','https://github.com/modelcontextprotocol/python-sdk — SDK رسمی استفاده‌شده برای FastMCP و ClientSession.'),('MCP specification','https://modelcontextprotocol.io/specification — مفاهیم tools، resources، prompts و stdio.'),('LangGraph persistence / interrupts','https://docs.langchain.com/oss/python/langgraph/persistence و https://docs.langchain.com/oss/python/langgraph/interrupts'),('Pydantic strict mode','https://docs.pydantic.dev/latest/concepts/strict_mode/'),('scikit-learn','https://scikit-learn.org/stable/modules/feature_extraction.html و مستندات LogisticRegression، Pipeline و f1_score.'),('SQLite','https://www.sqlite.org/foreignkeys.html و https://www.sqlite.org/lang_transaction.html'),('Bootstrap','Efron, B. & Tibshirani, R. J. (1993). An Introduction to the Bootstrap. Chapman & Hall/CRC.'),('Jensen–Shannon divergence','Lin, J. (1991). Divergence measures based on the Shannon entropy. IEEE Transactions on Information Theory, 37(1), 145–151. DOI: 10.1109/18.61115.')]
table(refs,heads=['منبع','کاربرد یا نشانی'])
para('نشانی‌های مستندات برای مراجعهٔ روش‌شناختی آمده‌اند؛ گزارش ادعای مرور زندهٔ همهٔ صفحات وب یا اعتبارسنجی آخرین ویرایش آن‌ها را ندارد. نسخه‌های واقعاً اجراشده در جدول زیر از محیط استخراج شده‌اند.')
table([('Python',R['12.10']['python_version'])]+list(R['12.10']['versions'].items()),heads=['مولفه','نسخهٔ اجراشده'])
h('راهنمای بازاجرا',2)
para('بستهٔ اصلی دانشجو را استخراج و مسیر Day4 را در DAY4_ROOT قرار دهید. ZIP شواهد را در پوشه‌ای جدا باز کنید. requirements-executed.txt نسخه‌های کتابخانه‌های اصلی همین اجرا را ثبت می‌کند. هیچ credential واقعی برای SQLite، MCP محلی یا تصمیم‌گیر fixture لازم نیست.')
code('python -m venv .venv\nsource .venv/bin/activate\npython -m pip install -r requirements-executed.txt\nDAY4_ROOT=/absolute/path/to/Day4 python run_all.py\nDAY4_ROOT=/absolute/path/to/Day4 python rebuild.py --out fresh_rebuild')
para('در Windows باید متغیر DAY4_ROOT با روش همان shell تنظیم شود. نوت‌بوک را از پوشهٔ شواهد باز و با kernel دارای وابستگی‌ها اجرا کنید. سلول راه‌اندازی run_all.py را واقعاً اجرا می‌کند؛ سلول هر سؤال، کد مربوط و نتیجهٔ تولیدشده را به تفکیک نشان می‌دهد. کدها به شبکه یا LLM زنده نیاز ندارند. نصب اولیهٔ کتابخانه‌ها ممکن است دسترسی به مخزن بسته‌ها بخواهد.')
para('نکتهٔ تحویل: فایل Word برای مطالعه و استفاده مطابق درخواست کاربر است. فرمت رسمی صفحهٔ تکلیف نوت‌بوک اجراشده و ZIP شواهد است. نمرهٔ نهایی، معیار خصوصی test و بررسی مورد اعتماد مدرس از این گزارش قابل استنتاج نیستند.')
word_path=OUT/'Day4_Complete_Persian_Answers.docx';D.save(word_path)
# Save answer catalog used by the notebook, without a student-supplied grade.
catalog={**{q:dict(option=x['option'],analysis=x['analysis']) for q,x in concept.items()},**{q:dict(**analysis[q],result=R[q],source=blocks[q]) for q in analysis}}
(BASE/'answer_catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
if '--document-only' in sys.argv:
 print(json.dumps({'word':str(word_path),'questions':144,'word_bytes':word_path.stat().st_size}));sys.exit(0)
# A real notebook will execute the central experiment, then expose each numbered result.
import nbformat as nbf
nb=nbf.v4.new_notebook();cells=[]
cells.append(nbf.v4.new_markdown_cell('<div dir="rtl"><h1>پاسخ کامل روز چهارم</h1><p>اجرای مرکزی همهٔ ۹۶ آزمون عملی در سلول راه‌اندازی انجام می‌شود. سلول هر سؤال کد همان بلوک و خروجی واقعی گزارش مرکزی را نمایش می‌دهد. تصمیم‌گیر و reviewer آزمایشی‌اند؛ LLM زنده اجرا نمی‌شود.</p></div>'))
cells.append(nbf.v4.new_code_cell("import json, runpy\nfrom pathlib import Path\n# Execute all experiments, including real MCP, SQLite, LangGraph and fresh rebuild.\nrunpy.run_path('run_all.py', run_name='__main__')\nresults = json.loads(Path('Day4_Run_Output/answers_practical.json').read_text())\ncatalog = json.loads(Path('answer_catalog.json').read_text())\nprint('All 96 practical experiments executed; inspect checker and execution_scope reports.')"))
for section in S:
 for q in section['questions']:
  qid=q['id'];cells.append(nbf.v4.new_markdown_cell(f'<div dir="rtl"><h2>زیرسؤال {qid}</h2><p>{q["prompt"]}</p></div>'))
  if int(qid.split('.')[0])<5:
   cell=f"answer = {repr({'question_id':qid,'selected_option':concept[qid]['option']})}\nprint(json.dumps(answer, ensure_ascii=False, indent=2))"
   desc=concept[qid]['analysis']
  else:
   cell=f"# The following experiment block was executed by run_all.py in setup.\n# Printing source preserves the shared state and avoids repeating side effects.\nprint(catalog[{qid!r}]['source'])\nprint('RECORDED OUTPUT FROM THE EXECUTED EXPERIMENT:')\nprint(json.dumps(results[{qid!r}], ensure_ascii=False, indent=2))"
   desc=analysis[qid]['method']+'<br/><br/>'+analysis[qid]['analysis']
  cells.append(nbf.v4.new_code_cell(cell));cells.append(nbf.v4.new_markdown_cell('<div dir="rtl"><b>تحلیل فارسی</b><p>'+desc+'</p></div>'))
nb.cells=cells;nb.metadata.kernelspec=dict(display_name='Python 3',language='python',name='python3');nb.metadata.language_info={'name':'python','version':sys.version.split()[0]}
nbf.write(nb,BASE/'Day4_Executed.ipynb')
print(json.dumps({'word':str(word_path),'questions':144,'notebook_cells':len(cells),'word_bytes':word_path.stat().st_size}))
