from pathlib import Path
import sys,json,argparse,subprocess
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'Day4_Code'))
from agent_lab import *
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args();out=args.out;out.mkdir(exist_ok=True,parents=True)
for name in ['application.sqlite','checkpoints.sqlite']:
 if (out/name).exists():(out/name).unlink()
store=Store(out/'application.sqlite');p=next(iter(PEOPLE.values()));eid=p['employee_id'];d=Dispatcher();cfg={'configurable':{'thread_id':'fresh-rebuild'}}
with SqliteSaver.from_conn_string(str(out/'checkpoints.sqlite')) as saver:
 g=build_graph(store,saver);pending=g.invoke({'employee_id':eid},cfg)
 assert pending.get('__interrupt__') and store.version('org-a',eid)==0
store.close();store=Store(out/'application.sqlite')
with SqliteSaver.from_conn_string(str(out/'checkpoints.sqlite')) as saver:
 g=build_graph(store,saver);g.invoke(Command(resume={'approved':True,'reviewer':'fixture-hr-reviewer'}),cfg)
e=next(e for e in p['evidence'] if e['verified']);store.remember(d,eid,e['evidence_id'],e['text'],30);store.claim('fresh-rebuild-event');store.close()
r=subprocess.run([sys.executable,'-I',str(ROOT/'Day4_Grading/check_submission.py'),'--root',str(ROOT),'--application-db',str(out/'application.sqlite'),'--checkpoint-db',str(out/'checkpoints.sqlite'),'--output',str(out/'database_check.json')],capture_output=True,text=True)
report=json.loads((out/'database_check.json').read_text());print(json.dumps({'status':report['status'],'passed':sum(x['passed'] for x in report['checks']),'checks':len(report['checks']),'exit_code':r.returncode}))
