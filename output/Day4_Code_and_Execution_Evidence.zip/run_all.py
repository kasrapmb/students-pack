from pathlib import Path
import sys,os,json,re,copy,hashlib,asyncio,subprocess,time,secrets,importlib.metadata,platform
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import numpy as np,pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.dummy import DummyClassifier
from sklearn.metrics import f1_score,accuracy_score,confusion_matrix
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'Day4_Code'))
from agent_lab import *
OUT=BASE/'Day4_Run_Output';OUT.mkdir(exist_ok=True)
REPORT={}
def save(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=lambda x:x.item() if hasattr(x,'item') else str(x)))
def record(q,**values):REPORT[q]=values;return values
def rejected(fn):
 try:fn();return False
 except (ValueError,PermissionError,TypeError):return True
P=list(PEOPLE.values());person=P[0];eid=person['employee_id'];d=Dispatcher();profile=make_profile(person)
foreign=next(p for p in P if p['tenant']!='org-a')['employee_id']
otherdept=next(p for p in P if p['tenant']=='org-a' and p['department']!='finance')['employee_id']
# Q 5.1
policies=POLICIES;docs=readjl(DATA/'02_Context/documents.jsonl');req=pd.DataFrame(readjl(DATA/'03_Requests/requests.jsonl'))
clean=lambda s:re.sub(r';\s*request variant\s+\d+\.?\s*$','',s,flags=re.I).strip().lower()
req['clean']=req.text.map(clean)
splits=['train','dev','test'];families={s:set(req.loc[req.split==s,'template_group']) for s in splits};texts={s:set(req.loc[req.split==s,'clean']) for s in splits}
record('5.1',people=len(P),policies=len(policies),documents=len(docs),split_sizes=req.split.value_counts().to_dict(),unique_people=len(PEOPLE)==len(P),unique_requests=req.request_id.is_unique,unique_documents=len({x['doc_id'] for x in docs})==len(docs),disjoint_families=all(not families[a]&families[b] for i,a in enumerate(splits) for b in splits[i+1:]),disjoint_clean_text=all(not texts[a]&texts[b] for i,a in enumerate(splits) for b in splits[i+1:]))
# Q 5.2
allowed=[x for x in docs if (x['tenant'],x['department'])==('org-a','finance')]
record('5.2',allowed_documents=len(allowed),scope_isolated=all((x['tenant'],x['department'])==('org-a','finance') for x in allowed))
# Q 5.3
parts=pd.read_csv(DATA/'02_Context/budget_parts.csv')
def allocate(window,reserve):
 capacity=window-reserve;mandatory=parts[parts.mandatory];selected=mandatory.part.tolist();used=int(mandatory.estimated_tokens.sum())
 if used>capacity:raise ValueError('mandatory_context_exceeds_capacity')
 for r in parts[~parts.mandatory].sort_values('priority',ascending=False,kind='stable').itertuples():
  if used+r.estimated_tokens<=capacity:selected.append(r.part);used+=r.estimated_tokens
 return dict(selected=selected,input_used=used,input_remaining=capacity-used)
record('5.3',**allocate(1200,200))
# Q 5.4
record('5.4',insufficient_budget_rejected=rejected(lambda:allocate(600,200)),mandatory_tokens=int(parts[parts.mandatory].estimated_tokens.sum()),input_capacity=400)
# Q 5.5
vector=TfidfVectorizer();matrix=vector.fit_transform([x['text'] for x in allowed])
def retrieve(query,limit):
 if type(limit) is not int or limit<1:raise ValueError('invalid_limit')
 scores=(matrix@vector.transform([query]).T).toarray().ravel();order=np.argsort(-scores,kind='stable')[:limit]
 return [dict(doc_id=allowed[i]['doc_id'],score=float(scores[i])) for i in order]
retrieved=retrieve('reconciliation evidence',4)
record('5.5',retrieved_count=len(retrieved),ranking=retrieved,zero_limit_rejected=rejected(lambda:retrieve('x',0)))
# Q 5.6
redact=lambda text:re.sub(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b','[REDACTED_EMAIL]',text,flags=re.I)
sample='Contact person0@example.invalid. Preserve reconciliation evidence.';redacted=redact(sample)
record('5.6',email_removed='person0@example.invalid' not in redacted,work_text_preserved='Preserve reconciliation evidence.' in redacted,redacted_text=redacted)
# Q 5.7
canonical_text=lambda text:' '.join(text.split()).casefold()
unique={};
for x in allowed:unique.setdefault(canonical_text(x['text']),x)
before=sum(len(x['text']) for x in allowed);after=sum(len(x['text']) for x in unique.values())
record('5.7',before_count=len(allowed),after_count=len(unique),character_reduction=1-after/before,canonicalization='Unicode casefold and whitespace normalization; punctuation preserved')
# Q 5.8
full=person['evidence'];small=[{k:e[k] for k in ['evidence_id','skill','verified']} for e in full]
save('full_evidence.json',full)
record('5.8',references_retained=len(small),json_character_reduction=1-len(canonical(small))/len(canonical(full)),compact=small,serialization='canonical JSON, UTF-8 characters rather than byte count')
# Q 5.9
policy_context={k:v for k,v in policies[0].items() if k in ['department','required_skills','min_evidence','version']}
evidence_context=dict(employee_id=eid,evidence=small,tools=['get_evidence'])
record('5.9',minimal_policy_context='email' not in policy_context and 'resume' not in policy_context,evidence_read_only=all(x in SCHEMAS for x in evidence_context['tools']),policy_context=policy_context,evidence_tools=evidence_context['tools'])
# Q 5.10
validate_profile(profile,d);save('selected_profile.json',profile)
record('5.10',claim_count=len(profile['claims']),decision=profile['decision'],profile=profile)
# Q 5.11
badquote=copy.deepcopy(profile);badquote['claims'][0]['quote']='Invented quotation'
badid=copy.deepcopy(profile);badid['claims'][0]['evidence_id']='fake-evidence'
record('5.11',tampered_quote_rejected=rejected(lambda:validate_profile(badquote,d)),fake_reference_rejected=rejected(lambda:validate_profile(badid,d)))
# Q 5.12
coverage=pd.DataFrame([dict(department=p['department'],coverage=len({c['skill'] for c in make_profile(p)['claims']})/4) for p in P]);means=coverage.groupby('department').coverage.mean()
means.plot.bar(color=['#123d59','#289e9c','#a47830'],ylim=(0,1),rot=0,ylabel='Verified skill coverage');plt.tight_layout();plt.savefig(OUT/'coverage.png',dpi=160);plt.close()
record('5.12',mean_coverage=float(coverage.coverage.mean()),department_means=means.to_dict())
# Q 6.1
schemas={k:v.model_json_schema() for k,v in SCHEMAS.items()};save('tool_schemas.json',schemas)
record('6.1',employee_required=len(schemas['get_employee']['required']),policy_required=len(schemas['get_department_context']['required']),extra_fields_forbidden=all(s['additionalProperties'] is False for s in schemas.values()))
# Q 6.2
d2=Dispatcher();employee=d2.call('get_employee',{'employee_id':eid});policy=d2.call('get_department_context',{'department':'finance'});evidence=d2.call('get_evidence',{'employee_id':eid})
record('6.2',successful_calls=d2.calls,email_removed='email' not in employee,evidence_count=len(evidence))
# Q 6.3
invalid_calls=[('get_employee',{'employee_id':3}),('get_employee',{'employee_id':eid,'tenant':'org-b'}),('get_department_context',{'department':'legal'}),('shell',{'command':'not executed'})]
record('6.3',rejected_inputs=sum(rejected(lambda n=n,a=a:Dispatcher().call(n,a)) for n,a in invalid_calls),tests=4)
# Q 6.4
record('6.4',cross_tenant_rejected=rejected(lambda:d.call('get_employee',{'employee_id':foreign})),cross_department_rejected=rejected(lambda:d.call('get_employee',{'employee_id':otherdept})))
# Q 6.5
contract=dict(server='day4-local-skills',transport='stdio',tools=list(SCHEMAS),resources=['policy://org-a/finance'],prompts=['inventory_instructions'],scope={'tenant':'org-a','department':'finance'},identity='trusted application fixture; not enterprise authentication')
save('mcp_contract.json',contract);record('6.5',mcp_tools=3,transport='stdio')
# Q 6.6
probe=subprocess.run([sys.executable,str(BASE/'Day4_Code/mcp_probe.py')],capture_output=True,text=True,check=True)
mcp_result=json.loads(probe.stdout);save('mcp_probe.json',mcp_result)
record('6.6',discovered_tools=mcp_result['tools'],resources=mcp_result['resources'],prompts=mcp_result['prompts'],read_success=mcp_result['read_success'])
# Q 6.7
record('6.7',mcp_cross_tenant_rejected=mcp_result['cross_tenant_rejected'],mcp_invalid_department_rejected=mcp_result['invalid_department_rejected'])
# Q 6.8
def bounded_error(error):
 return {'code':'SCOPE_DENIED' if isinstance(error,PermissionError) else 'INVALID_REQUEST','retryable':False}
try:d.call('get_employee',{'employee_id':foreign})
except PermissionError as error:safe_error=bounded_error(error)
record('6.8',scope_retryable=safe_error['retryable'],error_fields=len(safe_error),safe_error=safe_error)
# Q 6.9
responses=readjl(DATA/'05_Tools/model_responses.jsonl');invalid=sum(rejected(lambda x=x:validate_action(x['model_output'])) for x in responses)
record('6.9',valid_structural=len(responses)-invalid,invalid=invalid)
# Q 6.10
hash_before=digest(schemas);hash_after=digest({**schemas,'new_read_only_tool':{'type':'object'}})
record('6.10',hash_changed=hash_before!=hash_after,hex_length=len(hash_before),toolset_hash=hash_before)
# Q 6.11
record('6.11',live_llm_reference=False,executed_model='OfflineDecisionModel fixture',optional_adapter_executed=False,interface='next_action(employee_id, observations) -> validated tool/final action')
# Q 6.12
forbidden=['arbitrary_sql','shell_exec','external_send','general_write']
connection={**contract,'source':'Day4_Code/mcp_server.py','sdk_version':importlib.metadata.version('mcp'),'forbidden':forbidden,'a2a_complete':False}
save('connection_sheet.json',connection)
record('6.12',forbidden_capabilities=len(forbidden),a2a_complete=False,sdk_version=connection['sdk_version'])
# Q 7.1
action=dict(kind='tool',name='get_employee',arguments={'employee_id':eid})
cases=[action,dict(kind='tool',name='shell',arguments={}),dict(kind='final',text='')];bad=sum(rejected(lambda x=x:validate_action(x)) for x in cases)
record('7.1',accepted=len(cases)-bad,rejected=bad)
# Q 7.2
normal=run_loop(OfflineDecisionModel(),eid,Dispatcher());save('agent_trace.json',normal)
record('7.2',status=normal['status'],trace_steps=len(normal['trace']),tool_order=[x['name'] for x in normal['trace'] if x['kind']=='tool'])
# Q 7.3
r=run_loop(FixedModel(action),eid,Dispatcher());record('7.3',stop_reason=r['status'],actual_tool_calls=r['tool_calls'])
# Q 7.4
r=run_loop(OfflineDecisionModel(),eid,Dispatcher(),max_steps=2);record('7.4',stop_reason=r['status'],actual_tool_calls=r['tool_calls'],final_exists=r['final'] is not None)
# Q 7.5
r=run_loop(OfflineDecisionModel(),eid,Dispatcher(),budget=.001);record('7.5',stop_reason=r['status'],actual_tool_calls=r['tool_calls'],estimated_cost=r['cost'])
# Q 7.6
r=run_loop(FixedModel(action,delay=.025),eid,Dispatcher(),deadline_ms=1);record('7.6',stop_reason=r['status'],tools_after_deadline=r['tool_calls'])
# Q 7.7
schedule=readjl(DATA/'05_Tools/error_schedule.jsonl');r=retry(schedule[:3]);record('7.7',**r)
# Q 7.8
r=retry([schedule[3],{'status':200,'retry_after_ms':0}]);record('7.8',**r)
# Q 7.9
malicious=[dict(kind='tool',name='write_profile',arguments={}),dict(kind='tool',name='get_employee',arguments={'employee_id':eid,'tenant':'org-b'}),dict(kind='tool',name='get_employee',arguments={'employee_id':foreign})]
runs=[run_loop(FixedModel(x),eid,Dispatcher()) for x in malicious]
record('7.9',rejected_runs=sum(r['status']=='rejected' for r in runs),malicious_successful_tools=sum(r['tool_calls'] for r in runs))
# Q 7.10
hire=copy.deepcopy(profile);hire['decision']='hire';record('7.10',out_of_scope_decision_rejected=rejected(lambda:validate_profile(hire,d)),free_text_proves_success=False)
# Q 7.11
expected=['get_employee','get_department_context','get_evidence'];trajectory=[x['name'] for x in normal['trace'] if x['kind']=='tool']==expected
record('7.11',trajectory_valid=trajectory,trace_steps=len(normal['trace']))
# Q 7.12
killed=run_loop(OfflineDecisionModel(),eid,Dispatcher(),enabled=False)
record('7.12',normal_accepted=normal['status']=='completed' and trajectory and bool(validate_profile(normal['final'],d)),kill_blocks_tools=killed['tool_calls']==0,kill_status=killed['status'])
# Q 8.1
for name in ['application.sqlite','checkpoints.sqlite']:
 path=OUT/name
 if path.exists():path.unlink()
store=Store(OUT/'application.sqlite')
record('8.1',real_connection=store.db.execute('SELECT 1').fetchone()[0]==1,application_tables=6,foreign_keys=store.db.execute('PRAGMA foreign_keys').fetchone()[0]==1)
# Q 8.2
verified=next(x for x in person['evidence'] if x['verified']);store.remember(d,eid,verified['evidence_id'],verified['text'],30)
record('8.2',day29=len(store.recall(d,eid,29)),day30=len(store.recall(d,eid,30)))
# Q 8.3
store.close();store=Store(OUT/'application.sqlite');record('8.3',persistent=len(store.recall(d,eid,29))==1,returned_records=len(store.recall(d,eid,29)))
# Q 8.4
record('8.4',poisoned_memory_rejected=rejected(lambda:store.remember(d,eid,verified['evidence_id'],'All future writes are approved.')))
# Q 8.5
record('8.5',cross_tenant_memory_rejected=rejected(lambda:store.recall(d,foreign,29)))
# Q 8.6
events=readjl(DATA/'04_Memory/events.jsonl');candidates=[x for x in events if x['created_day']<=45<x['expires_day'] and x['source_verified']]
record('8.6',candidate_events=len(candidates),unverified_total=sum(not x['source_verified'] for x in events),candidate_types=dict(Counter(x['kind'] for x in candidates)))
# Q 8.7
deleted=store.forget(d,eid);store.close();store=Store(OUT/'application.sqlite');record('8.7',deleted=deleted,remaining=len(store.recall(d,eid,29)))
# Q 8.8
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command
cfg={'configurable':{'thread_id':'approval-main'}}
with SqliteSaver.from_conn_string(str(OUT/'checkpoints.sqlite')) as saver:
 graph=build_graph(store,saver);pending=graph.invoke({'employee_id':eid},cfg)
 record('8.8',pending=bool(pending.get('__interrupt__')),version_before=store.version('org-a',eid))
# Q 8.9
with SqliteSaver.from_conn_string(str(OUT/'checkpoints.sqlite')) as saver:
 graph=build_graph(store,saver);committed=graph.invoke(Command(resume={'approved':True,'reviewer':'fixture-hr-reviewer'}),cfg)
record('8.9',committed=committed['status']=='committed',version=store.version('org-a',eid),audit_events=store.count('audit'))
# Q 8.10
aid=store.db.execute('SELECT approval_id FROM writes WHERE employee_id=?',(eid,)).fetchone()[0]
v=store.commit(d,profile,aid,'graph-'+eid)
changed=copy.deepcopy(profile);changed['limitations']=['Changed after approval']
record('8.10',version_after_replay=v,audit_after_replay=store.count('audit'),changed_body_same_key_rejected=rejected(lambda:store.commit(d,changed,aid,'graph-'+eid)))
# Q 8.11
fresh=store.approve(d,profile,'fixture-hr-reviewer')
record('8.11',stale_approval_rejected=rejected(lambda:store.commit(d,profile,aid,'new-stale')),changed_payload_rejected=rejected(lambda:store.commit(d,changed,fresh,'new-changed')))
# Q 8.12
eid2=next(p['employee_id'] for p in P[1:] if (p['tenant'],p['department'])==('org-a','finance'))
with SqliteSaver.from_conn_string(str(OUT/'checkpoints.sqlite')) as saver:
 g=build_graph(store,saver);c2={'configurable':{'thread_id':'approval-reject'}};g.invoke({'employee_id':eid2},c2);denied=g.invoke(Command(resume={'approved':False,'reviewer':'fixture-hr-reviewer'}),c2)
store.remember(d,eid,verified['evidence_id'],verified['text'],30)
record('8.12',human_rejection_recorded=denied['status']=='rejected',rejected_employee_version=store.version('org-a',eid2),approved_employee_version=store.version('org-a',eid))
# Q 9.1
labels=pd.DataFrame(readjl(DATA/'03_Requests/labels_train_dev.jsonl'));joined=req.merge(labels[['request_id','route']],on='request_id',how='left',validate='one_to_one')
train=joined[joined.split=='train'];dev=joined[joined.split=='dev'];test=joined[joined.split=='test']
record('9.1',public_labels=int(joined.route.notna().sum()),unlabeled_test=int(test.route.isna().sum()),groups_disjoint=REPORT['5.1']['disjoint_families'])
# Q 9.2
dummy=DummyClassifier(strategy='most_frequent').fit(train[['clean']],train.route)
def fit_router(C):return make_pipeline(TfidfVectorizer(ngram_range=(1,2)),LogisticRegression(C=C,max_iter=1000,random_state=20261016)).fit(train.clean,train.route)
initial=fit_router(1)
record('9.2',majority_macro_f1=float(f1_score(dev.route,dummy.predict(dev[['clean']]),average='macro',zero_division=0)),router_macro_f1=float(f1_score(dev.route,initial.predict(dev.clean),average='macro',zero_division=0)))
# Q 9.3
models={C:fit_router(C) for C in [.1,1,10]};scores={C:float(f1_score(dev.route,m.predict(dev.clean),average='macro',zero_division=0)) for C,m in models.items()};chosen=max(sorted(scores),key=scores.get);router=models[chosen]
config=dict(C=chosen,dev_macro_f1=scores[chosen],candidate_scores=scores,ngram_range=[1,2],random_state=20261016,fit_split='train',selection_split='dev',threshold=.55,normalization='remove trailing request variant number, strip, lowercase',features='clean text only',test_prediction_policy='raw class argmax; threshold 0.55 is separate dev abstention experiment',private_test_metric='خصوصی')
save('locked_router_config.json',config)
probs_test=router.predict_proba(test.clean);probs_dev=router.predict_proba(dev.clean)
classes=router.classes_
def threshold_routes(probs):return [str(classes[i]) if float(p[i])>=.55 else 'clarify' for p in probs for i in [int(np.argmax(p))]]
test_routes=list(map(str,router.predict(test.clean)));dev_routes=list(map(str,router.predict(dev.clean)))
predictions=[dict(request_id=rid,route=route) for rid,route in zip(test.request_id,test_routes)]
(OUT/'route_predictions.jsonl').write_text('\n'.join(canonical(x) for x in predictions)+'\n')
record('9.3',selected_C=chosen,selected_dev_macro_f1=scores[chosen],candidate_scores=scores,private_test_metric='خصوصی')
# Q 9.4
accept=probs_dev.max(axis=1)>=.55;acc=float(accuracy_score(dev.route.to_numpy()[accept],router.predict(dev.clean)[accept])) if accept.any() else None
record('9.4',dev_coverage=float(accept.mean()),conditional_accuracy=acc,clarify_count=int((~accept).sum()),accepted=int(accept.sum()))
# Q 9.5
chain_inputs=[profile,badquote];chain_reports=[];stops=0
for obj in chain_inputs:
 try:chain_reports.append(validate_profile(obj,d))
 except ValueError:stops+=1
record('9.5',reports_created=len(chain_reports),gate_stops=stops)
# Q 9.6
def worker_evidence(p):return copy.deepcopy(p['evidence'])
def worker_policy(p):return copy.deepcopy(next(x for x in POLICIES if (x['tenant'],x['department'])==(p['tenant'],p['department'])))
def assemble(p,evidence,policy):
 obj=dict(employee_id=p['employee_id'],department=p['department'],claims=[dict(skill=e['skill'],evidence_id=e['evidence_id'],quote=e['text']) for e in evidence if e['verified'] and e['skill'] in policy['required_skills']],limitations=['Only verified documented skills; absence of evidence is not absence of ability.'],decision='skills_inventory_only');return validate_profile(obj,Dispatcher(Principal(p['tenant'],p['department'])))
def parallel_profile(p):
 with ThreadPoolExecutor(max_workers=2) as pool:
  f1=pool.submit(worker_evidence,p);f2=pool.submit(worker_policy,p);return assemble(p,f1.result(),f2.result())
parallel=parallel_profile(person)
record('9.6',workers=2,claims=len(parallel['claims']),same_as_single=parallel==profile)
# Q 9.7
worker_counts=Counter(2+int(len(make_profile(p)['claims'])<2) for p in P)
record('9.7',worker_distribution=dict(worker_counts),max_workers=max(worker_counts),scope_note='Each synthetic principal is separately matched to its own tenant/department; org-a finance principal is never elevated.')
# Q 9.8
checks=0;candidate=badquote
for _ in range(2):
 checks+=1
 try:validate_profile(candidate,d);break
 except ValueError:candidate=make_profile(person)
record('9.8',evaluations=checks,finally_accepted=not rejected(lambda:validate_profile(candidate,d)))
# Q 9.9
key=secrets.token_bytes(32);msg=sign_message({'claims':profile['claims']},'checker',100,'nonce-one',key)
tampered=copy.deepcopy(msg);tampered['body']={'claims':[]}
record('9.9',valid_message_accepted=verify_message(msg,'checker',10,key),invalid_rejected=sum([not verify_message(tampered,'checker',10,key),not verify_message(msg,'other-worker',10,key),not verify_message(msg,'checker',100,key)]))
# Q 9.10
record('9.10',valid_profile_passed=not rejected(lambda:validate_profile(profile,Dispatcher())),tampered_profile_rejected=rejected(lambda:validate_profile(badquote,Dispatcher())),worker_has_write=False,maker_fields=['employee_id','verified_evidence','required_skills'],checker_source='Independent Dispatcher read from original dataset; not maker summary')
# Q 9.11
def handoff(path,limit=4):
 seen=set();transfers=0
 for role in path:
  if role in seen:return 'cycle_detected'
  if transfers>limit:return 'handoff_limit'
  seen.add(role);transfers+=1
 return 'completed'
record('9.11',normal_status=handoff(['intake','profiler','reviewer']),cycle_status=handoff(['intake','profiler','intake']))
# Q 9.12
sample_people=P[:30];start=time.perf_counter();sequential=[assemble(p,worker_evidence(p),worker_policy(p)) for p in sample_people];seqms=(time.perf_counter()-start)*1000
start=time.perf_counter();parallel_outputs=[parallel_profile(p) for p in sample_people];parms=(time.perf_counter()-start)*1000
record('9.12',all_outputs_equal=sequential==parallel_outputs,sequential_ms=seqms,parallel_ms=parms,parallel_over_sequential=parms/seqms)
# Q 10.1
redteam=readjl(DATA/'06_Security/redteam.jsonl');mal=[x for x in redteam if x['malicious']];ben=[x for x in redteam if not x['malicious']]
record('10.1',malicious=len(mal),benign=len(ben),malicious_families=len({x['family'] for x in mal}),families=dict(Counter(x['family'] for x in mal)))
# Q 10.2
truth=[x['malicious'] for x in redteam];detected=[bool(re.search(r'\b(ignore|system)\b',x['payload'],re.I)) for x in redteam];cm=confusion_matrix(truth,detected,labels=[False,True]);tn,fp,fn,tp=map(int,cm.ravel())
plt.imshow(cm,cmap='Blues');plt.xticks([0,1],['Benign','Attack']);plt.yticks([0,1],['Benign','Attack']);plt.xlabel('Predicted');plt.ylabel('Actual')
for (i,j),v in np.ndenumerate(cm):plt.text(j,i,str(v),ha='center',va='center',color='black')
plt.tight_layout();plt.savefig(OUT/'detector_confusion.png',dpi=160);plt.close()
record('10.2',TPR=tp/(tp+fn),FPR=fp/(fp+tn),matrix=dict(TN=tn,FP=fp,FN=fn,TP=tp))
# Q 10.3
hijack=copy.deepcopy(profile);hijack['claims'][0]['skill']='unrelated';hijack['claims'][0]['quote']='Invented'
record('10.3',goal_hijack_blocked=rejected(lambda:validate_profile(hijack,d)))
# Q 10.4
record('10.4',external_send_blocked=rejected(lambda:d.call('send_external',{'destination':'external@example.invalid','body':'synthetic'})))
# Q 10.5
record('10.5',privilege_abuse_blocked=rejected(lambda:d.call('get_employee',{'employee_id':eid,'tenant':'org-b'})) and rejected(lambda:d.call('get_employee',{'employee_id':foreign})))
# Q 10.6
tool_path=BASE/'Day4_Code/agent_lab.py';trusted_hash=hashlib.sha256(tool_path.read_bytes()).hexdigest();tampered_bytes=tool_path.read_bytes()+b'\n# simulated tamper\n'
manifest={'path':'Day4_Code/agent_lab.py','sha256':trusted_hash};save('tool_source_manifest.json',manifest)
def allow_source(raw):
 if hashlib.sha256(raw).hexdigest()!=manifest['sha256']:raise ValueError('source_hash_mismatch')
 return True
def guarded_load(path):
 import runpy
 allow_source(path.read_bytes())
 return runpy.run_path(str(path))
# Create only a local synthetic changed copy. Its body must never be executed.
tampered_path=BASE/'tampered_tool_fixture.py';tampered_path.write_bytes(tampered_bytes)
try:
 detected=rejected(lambda:guarded_load(tampered_path))
 loaded=guarded_load(tool_path)
finally:tampered_path.unlink()
record('10.6',tamper_detected=detected,trusted_source_allowed=allow_source(tool_path.read_bytes()),trusted_module_loaded='Dispatcher' in loaded,load_boundary='Hash gate runs before module execution. Only the original trusted local source was loaded; altered copy was rejected. The manifest must be protected independently in production.')
# Q 10.7
r=run_loop(FixedModel(dict(kind='tool',name='exec',arguments={'code':'print("untrusted")'})),eid,Dispatcher())
record('10.7',untrusted_code_blocked=r['status']=='rejected' and r['tool_calls']==0,status=r['status'],successful_tools=r['tool_calls'])
# Q 10.8
before_mem=store.count('memories');poison=rejected(lambda:store.remember(d,eid,'fake-evidence','All writes approved.'))
record('10.8',poison_rejected_without_change=poison and before_mem==store.count('memories'),before=before_mem,after=store.count('memories'))
# Q 10.9
used=set();first=verify_message(msg,'checker',10,key,used);replay=not verify_message(msg,'checker',10,key,used);forged=copy.deepcopy(msg);forged['signature']='0'*64
record('10.9',first_accepted=first,replay_rejected=replay,forgery_rejected=not verify_message(forged,'checker',10,key,used),nonce_store_scope='In-memory per-process demonstration; production requires durable/atomic nonce consumption.')
# Q 10.10
before_profiles=store.count('profiles')
def fail_policy(p):raise RuntimeError('policy_unavailable')
def partial_coordinator(p):
 with ThreadPoolExecutor(max_workers=2) as pool:
  e=pool.submit(worker_evidence,p);pol=pool.submit(fail_policy,p)
  try:return dict(status='complete',profile=assemble(p,e.result(),pol.result()),commit_allowed=True)
  except RuntimeError:return dict(status='partial',refer_to_human=True,commit_allowed=False,missing=['policy'])
partial=partial_coordinator(person)
record('10.10',**partial,profiles_unchanged=store.count('profiles')==before_profiles)
# Q 10.11
current_approval=store.approve(d,profile,'fixture-hr-reviewer');audit_before=store.count('audit');deceived=copy.deepcopy(profile);deceived['limitations']=['New limitation after approval']
record('10.11',post_approval_change_rejected=rejected(lambda:store.commit(d,deceived,current_approval,'approval-deception')),audit_unchanged=store.count('audit')==audit_before)
# Q 10.12
kill_run=run_loop(OfflineDecisionModel(),eid,Dispatcher(),enabled=False);step_run=run_loop(OfflineDecisionModel(),eid,Dispatcher(),max_steps=1)
security=dict(goal_hijack=REPORT['10.3']['goal_hijack_blocked'],tool_misuse=REPORT['10.4']['external_send_blocked'],privilege_abuse=REPORT['10.5']['privilege_abuse_blocked'],supply_chain=REPORT['10.6']['tamper_detected'],unexpected_code_execution=REPORT['10.7']['untrusted_code_blocked'],memory_poisoning=REPORT['10.8']['poison_rejected_without_change'],forged_message=all(REPORT['10.9'][x] for x in ['first_accepted','replay_rejected','forgery_rejected']),cascading_failure=partial['status']=='partial' and not partial['commit_allowed'],approval_deception=all(REPORT['10.11'].values()),rogue_agent=kill_run['status']=='killed' and kill_run['tool_calls']==0 and step_run['status']=='max_steps' and step_run['tool_calls']==1)
save('security_tests.json',security);record('10.12',families_tested=len(security),successful_controls=sum(security.values()),results=security)
# Q 11.1
runs=pd.read_csv(DATA/'07_Evaluation/runs.csv');spans=pd.read_csv(DATA/'07_Evaluation/spans.csv');prices=pd.read_csv(DATA/'07_Evaluation/prices.csv')
paired=runs.groupby('scenario_id').variant.agg(lambda x:set(x)=={'baseline','candidate'} and len(x)==2).all()
record('11.1',runs=len(runs),scenarios=runs.scenario_id.nunique(),spans=len(spans),paired=bool(paired),split_counts=runs.groupby(['split','variant']).size().to_dict())
# Q 11.2
devruns=runs[runs.split=='dev'];devstats=devruns.groupby('variant')[['success','policy_violation']].mean()
devstats.plot.bar(rot=0,ylim=(0,1));plt.tight_layout();plt.savefig(OUT/'dev_comparison.png',dpi=160);plt.close()
record('11.2',baseline_success=float(devstats.loc['baseline','success']),candidate_success=float(devstats.loc['candidate','success']),candidate_violation=float(devstats.loc['candidate','policy_violation']),table=devstats.to_dict(orient='index'))
# Q 11.3
allowed_routes=set(labels.route)
record('11.3',test_predictions=len(predictions),complete_unique_coverage=len({x['request_id'] for x in predictions})==len(test) and {x['request_id'] for x in predictions}==set(test.request_id),all_routes_allowed=all(x['route'] in allowed_routes for x in predictions),route_distribution=dict(Counter(test_routes)))
# Q 11.4
pairs=runs[runs.split=='test'].pivot(index='scenario_id',columns='variant',values='success').astype(float);diff=(pairs.candidate-pairs.baseline).to_numpy();rng=np.random.default_rng(20261016);boots=diff[rng.integers(0,len(diff),size=(2000,len(diff)))].mean(axis=1);lo,hi=np.quantile(boots,[.025,.975])
record('11.4',mean_difference=float(diff.mean()),ci95_lower=float(lo),ci95_upper=float(hi),test_pairs=len(diff),seed=20261016,bootstrap_repetitions=2000)
# Q 11.5
by=spans.groupby('run_id');wall=by.end_ms.max()-by.start_ms.min();work=spans.assign(work=spans.end_ms-spans.start_ms).groupby('run_id').work.sum();runs=runs.merge(wall.rename('wall'),on='run_id',validate='one_to_one')
record('11.5',wall_P50_ms=float(np.quantile(wall,.5)),wall_P95_ms=float(np.quantile(wall,.95)),duration_mismatches=int((runs.wall!=runs.duration_ms).sum()),runs_work_exceeds_wall=int((work>wall).sum()))
# Q 11.6
price=prices.iloc[0];runs['cost_usd']=(runs.input_tokens*price.input_usd_per_million+runs.output_tokens*price.output_usd_per_million)/1e6
costs=runs.groupby('variant').cost_usd.sum();successes=runs.groupby('variant').success.sum()
record('11.6',total_cost_usd=float(runs.cost_usd.sum()),candidate_cost_per_success_usd=float(costs['candidate']/successes['candidate']),cost_by_variant_usd=costs.to_dict(),cost_per_success_usd=(costs/successes).to_dict(),unit='USD, synthetic price')
# Q 11.7
weighted=runs.correct_calls.sum()/runs.tool_calls.sum();per_run=(runs.correct_calls/runs.tool_calls.replace(0,np.nan)).mean()
record('11.7',call_weighted_accuracy=float(weighted),mean_run_accuracy=float(per_run),zero_call_runs=int((runs.tool_calls==0).sum()))
# Q 11.8
safe_success=runs.success & ~runs.policy_violation;safety=runs.assign(safe=safe_success).groupby('variant')[['success','safe']].mean()
record('11.8',success_with_violation=int((runs.success & runs.policy_violation).sum()),safe_success_rate=float(safe_success.mean()),raw_success_rate=float(runs.success.mean()),by_variant=safety.to_dict(orient='index'))
# Q 11.9
edits=runs.groupby('variant').human_edit.mean();record('11.9',baseline_edit_rate=float(edits['baseline']),candidate_edit_rate=float(edits['candidate']))
# Q 11.10
audit=pd.read_csv(DATA/'07_Evaluation/audit_groups.csv');grouped=runs[runs.variant=='candidate'].merge(audit,on='employee_id',validate='many_to_one').groupby('audit_group').success.agg(['size','mean'])
record('11.10',groups=grouped.to_dict(orient='index'),success_gap=float(grouped['mean'].max()-grouped['mean'].min()))
# Q 11.11
routes=sorted(set(dev_routes)|set(test_routes)|allowed_routes);eps=1e-12
p=np.array([dev_routes.count(x) for x in routes],float)+eps;q=np.array([test_routes.count(x) for x in routes],float)+eps;p/=p.sum();q/=q.sum();m=(p+q)/2;js=.5*np.sum(p*np.log(p/m))+.5*np.sum(q*np.log(q/m))
record('11.11',JS_divergence=float(js),natural_log_upper_bound=float(np.log(2)),dev_counts=dict(Counter(dev_routes)),test_counts=dict(Counter(test_routes)),smoothing=eps)
# Q 11.12
quality=dict(uniqueness=bool(runs.run_id.is_unique and spans.span_id.is_unique),span_join=bool(set(spans.run_id)<=set(runs.run_id)),nonnegative_intervals=bool((spans.start_ms>=0).all() and (spans.end_ms>=spans.start_ms).all()),correct_calls_bounded=bool((runs.correct_calls>=0).all() and (runs.correct_calls<=runs.tool_calls).all()))
record('11.12',successful_checks=sum(quality.values()),quality_checks=4,results=quality)
# Q 12.1
p95=float(np.quantile(runs.loc[(runs.split=='dev')&(runs.variant=='candidate'),'wall'],.95));gate=dict(quality=REPORT['11.2']['candidate_success']-REPORT['11.2']['baseline_success']>=.03,policy=REPORT['11.2']['candidate_violation']<=.02,latency=p95<=2300)
gate['allowed']=all(gate.values());gate['candidate_dev_P95']=p95;save('locked_regression_gate.json',gate);record('12.1',**gate)
# Q 12.2
traffic=pd.read_csv(DATA/'08_Rollout/traffic.csv');hash_bucket=lambda rid:int(hashlib.sha256(rid.encode()).hexdigest(),16)%100
canary=traffic.request_id.map(hash_bucket).lt(5)&traffic.feature_enabled
record('12.2',canary_requests=int(canary.sum()),total_requests=len(traffic),observed_fraction=float(canary.mean()),feature_flag_respected=not bool((canary & ~traffic.feature_enabled).any()),hash_rule='unsigned full SHA256 integer modulo 100 < 5, AND feature_enabled')
# Q 12.3
before=store.count('profiles');shadow=run_loop(OfflineDecisionModel(),eid,Dispatcher());after=store.count('profiles')
record('12.3',shadow_completed=shadow['status']=='completed',profiles_unchanged=before==after,before_profiles=before,after_profiles=after)
# Q 12.4
new=sum(store.claim(x) for x in traffic.event_key)
record('12.4',new_jobs=new,duplicate_deliveries=len(traffic)-new,unique_events=int(traffic.event_key.nunique()))
# Q 12.5
store.close();checker_path=ROOT/'Day4_Grading/check_submission.py'
cmd=[sys.executable,'-I',str(checker_path),'--root',str(ROOT),'--application-db',str(OUT/'application.sqlite'),'--checkpoint-db',str(OUT/'checkpoints.sqlite'),'--output',str(OUT/'database_check.json')]
checkrun=subprocess.run(cmd,capture_output=True,text=True);checker=json.loads((OUT/'database_check.json').read_text())
record('12.5',status=checker['status'],checks=len(checker['checks']),passed=sum(x['passed'] for x in checker['checks']),exit_code=checkrun.returncode)
# Q 12.6
fresh_dir=OUT/'rebuild';fresh_dir.mkdir(exist_ok=True)
reb=subprocess.run([sys.executable,str(BASE/'rebuild.py'),'--out',str(fresh_dir)],capture_output=True,text=True,check=True)
rebresult=json.loads(reb.stdout);save('rebuild_report.json',rebresult)
record('12.6',status=rebresult['status'],passed=rebresult['passed'],fresh_process=True)
# Q 12.7
card=dict(owner='Student exercise owner',purpose='Verified skills inventory only',scope={'tenant':'org-a','department':'finance'},tools=list(SCHEMAS),human_authority='L4 Approver',data_limits='Synthetic scoped records; no hiring/salary; redact email',budget={'steps':5,'estimated_tool_cost':.01,'total_budget':1,'deadline_ms':1000},escalation='Missing evidence, policy failure, conflict or rejected validation -> reviewer',kill_switch='feature_enabled false before tool dispatch',execution_mode='Local POC; offline decision fixture')
save('agent_card.json',card);required_card={'owner','purpose','scope','tools','human_authority','data_limits','budget','escalation','kill_switch','execution_mode'}
record('12.7',required_fields=10,complete=required_card<=set(card))
# Q 12.8
manifest_files=['route_predictions.jsonl','agent_trace.json','database_check.json','agent_card.json','locked_router_config.json']
handoff_manifest=[dict(path=f,bytes=(OUT/f).stat().st_size,sha256=hashlib.sha256((OUT/f).read_bytes()).hexdigest()) for f in manifest_files];save('handoff_manifest.json',handoff_manifest)
record('12.8',manifest_file_count=len(handoff_manifest),hash_structure_valid=all(re.fullmatch('[0-9a-f]{64}',x['sha256']) for x in handoff_manifest))
# Q 12.9
schema=json.loads((ROOT/'Day4_Grading/question_schema.json').read_text())
# schema layout is inspected independently; trusted question weights override student values.
questions=[q for section in schema for q in section['questions']];total=sum(float(x['score']) for x in questions)
trusted_weights={q['id']:q['score'] for q in questions}
student_submission={'id':'1.1','score':999}
effective_weight=trusted_weights[student_submission['id']]
record('12.9',trusted_questions=len(questions),trusted_total_points=total,fake_999_discarded=effective_weight==0.5 and effective_weight!=student_submission['score'],first_real_weight=questions[0]['score'])
# Q 12.10
scope=dict(real=['SQLite application DB','MCP stdio SDK server/client','LangGraph SQLite interrupt and resume'],fixture=['OfflineDecisionModel','reviewer identity','comparative evaluation logs'],not_executed=['Live LLM','Enterprise identity','Public deployment','Complete A2A'])
save('execution_scope.json',scope);record('12.10',real_components=len(scope['real']),live_llm_executed=False,python_version=platform.python_version(),versions={x:importlib.metadata.version(x) for x in ['mcp','langgraph','langgraph-checkpoint-sqlite','pydantic','scikit-learn','pandas','numpy']})
# Q 12.11
store=Store(OUT/'application.sqlite');audit_before=store.count('audit');incident_loop=run_loop(OfflineDecisionModel(),eid,Dispatcher(),enabled=False)
incident=dict(feature_enabled=False,new_tools=incident_loop['tool_calls'],loop_status=incident_loop['status'],next_mode='shadow',audit_preserved=store.count('audit')==audit_before);save('incident_decision.json',incident);record('12.11',**incident);store.close()
# Q 12.12
data_manifest=json.loads((DATA/'manifest.json').read_text());matches=all(hashlib.sha256((DATA/x['path']).read_bytes()).hexdigest()==x['sha256'] and (DATA/x['path']).stat().st_size==x['bytes'] for x in data_manifest)
record('12.12',all_data_hashes_match=matches,security_controls_passed=sum(security.values()),database_checker_passed=checker['status']=='passed',practical_answers=len(REPORT)+1,test_predictions=len(predictions))
save('handoff_check.json',REPORT['12.12'])
# Normalize tuples and NumPy scalar values before machine-readable output.
def normalize(x):
 if isinstance(x,dict):return {str(k):normalize(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [normalize(v) for v in x]
 if hasattr(x,'item'):return x.item()
 return x
REPORT=normalize(REPORT);save('answers_practical.json',REPORT)
for section in range(5,13):save(f'section_{section}_report.json',{k:v for k,v in REPORT.items() if k.startswith(str(section)+'.')})
print(json.dumps({'answers':len(REPORT),'checker':REPORT['12.5'],'rebuild':REPORT['12.6'],'security':sum(security.values())}))
