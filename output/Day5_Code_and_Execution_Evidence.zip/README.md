# Day 5: real local inference and reproducible evidence

The notebook contains 48 conceptual answers and 96 actual executed practical code cells, each with its own question and Persian analysis. All 146 code cells, including setup and finalization, executed with zero error outputs. Nothing in this package invokes the course submission or grading endpoints.

## Reproduce

1. Extract the ORIGINAL day5-student-pack.zip and preserve its datasets, question schema and checker unchanged.
2. Download the two pinned Qwen2.5-0.5B-Instruct GGUFs using the original downloader. Expected revision, sizes and SHA-256 are in the original resource_manifest.json.
3. Obtain a native llama-server for your OS. This run used the official Linux x64 b11696 asset, verified against its published SHA-256 `6a04629ca5265eb4c5c7d6edec8d6fa429e7e7da2de1cd5d5e357a492fc8f802`. Its actual binary hash and --version output are in runtime_config.json. The Windows archive from the assignment was NOT executed on Linux.
4. Create an isolated Python environment and install requirements-executed.txt. Python 3.12.14 was used here. The assignment's suggested environment versions differ; only the executed versions are claimed.
5. Set DAY5_ROOT to the absolute path of the original Day5 directory and LLAMA_SERVER_PATH to your native engine, then execute the notebook from THIS folder. Alternatively run experiments.py from this folder to reproduce all practical experiments.

Linux/macOS example:

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-executed.txt
export DAY5_ROOT=/absolute/path/to/original/Day5
export LLAMA_SERVER_PATH=/absolute/path/to/llama-server
python experiments.py
python "$DAY5_ROOT/Day5_Grading/check_submission.py" --submission Day5_Run_Output --datasets "$DAY5_ROOT/Day5_Datasets" --output independent_check.json
```

For the notebook, select the corresponding Python kernel and execute all cells. Do not interpret the previous test run as data for changing selection. A clean rerun repeats the same frozen selection protocol; it does not optimize on test.

The numerical adapter uses real analytical MSE gradients and the Adam update in NumPy, for 250 epochs, alpha=2 and ranks 1,2,4. It does not require PyTorch, does not train a full LLM and is not QLoRA. This is an explicit alternative implementation of the permitted linear-layer experiment. The base stays unchanged and the trusted checker independently reconstructs the adapter predictions.

## Real execution versus simulation

REAL: both GGUF files and their hashes; native llama.cpp CPU processes; actual HTTP /health, /v1/models, /tokenize, constrained and unconstrained chat completions; per-request client clocks and usage; repeated-seed experiments; rank adapters and training curves; SQLite, auth=401 probe and independent checker subprocess.
SIMULATION/FIXTURE: hardware catalog and prices, queue scheduling, blocked KV and cache calculations, synthetic HR policies and deployment cases. Principal org-a is a trusted application fixture, not enterprise identity.
NOT EXECUTED: large MoE, vLLM, SGLang, full LLM fine-tuning, QLoRA, public deployment or automatic hiring/salary decisions.

No model weights, runtime binaries or shared datasets are in this evidence ZIP. No passwords, browser session state, API credentials or temporary runtime keys are included. Runtime auth tokens are generated in memory, used only on loopback and scrubbed from retained logs.

## Evaluation and limitations

- Two quant variants are compared on the same 12 dev cases with the same settings and separate unscored warmups. Selection uses only semantic accuracy, then actual file size. Both scored 1.0 accuracy and 1.0 schema validity on this tiny dev set, so q4_k_m was selected by the predeclared size tie-break.
- Only the selected quant generates the 12 test predictions. Test files contain no expected_days or correct. Private test accuracy and private adapter MSE remain `خصوصی`.
- Error audit includes every observable dev error and all test predictions as `private_test_unscored`. Zero dev errors must not be interpreted as zero private test errors.
- Bootstrap uses paired case IDs, 2000 resamples and a fixed seed. A zero interval when every paired outcome is equal is a property of this sample, not proof of model equivalence.
- Latency is warm nonstreaming client end-to-end latency, with linear quantiles and n=12 per quant. No TTFT is fabricated. Startup is separate and throughput is explicitly client output tokens / client elapsed seconds.
- The HR planner's action accuracy is 0.75 over the four cases. Its raw mistake is retained. The first case's plan is accepted only if it exactly requests get_policy/P-LEAVE with no extra keys. Its actual extraction is 22 and grounded, producing exactly one idempotent SQLite row with approved=0. No automatic HR decision is made.
- The scheduling simulator assumes aggregate prefill of 600 tokens/s, four slots, decode at 35 batch steps/s and globally paused decode during prefill. Static group slots remain reserved to batch end. Priority is intentionally not used. These are stated model assumptions, not measured engine service rates.
- KV allocation sums are token-slot totals over the trace, not simultaneous GPU bytes. Simulated cache keys include tenant and model revision.
- Hashes and a student-run checker report do not prove inference or a full grade. The original checker must be rerun by the instructor from a trusted copy. It validates 21 artifact-consistency checks, not all question reasoning or a promise of 100 points.

## Numeric-form ambiguities

Some original labels have numeric field types while their prompt asks for text. The response keeps the explanatory detail in the method field and uses the corresponding count in the numeric field: 5.12=2 real quant variants; 6.10=2 scenario volumes outside capacity (100000 and 1000000); 7.12=4 required evaluation categories; 8.4=1 listed model, with its exact ID retained in the actual output.

## Contents

Day5_Run_Output contains all reports, predictions, plots, raw model responses, training curves, selections, metadata, SQLite, trace, security tests, 21-check report and release card. Its handoff_manifest.json includes exactly the 11 artifacts required by the original checker. Other supporting outputs are intentionally outside that minimum manifest. artifact_index.json records all ZIP members other than itself.

core implementation: Day5_Code/local_lab.py
numbered executable experiments: experiments.py
Persian conceptual explanations: concepts.txt
Persian practical analyses: analyses.txt
form field mapping and complete response: form_answers.json
notebook generation and packaging helpers: make_notebook.py, prepare_submission.py
