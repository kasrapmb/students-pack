from pathlib import Path
import json,re,nbformat,sys,os
BASE=Path(__file__).resolve().parent;ROOT=Path(os.environ.get('DAY5_ROOT',str(BASE.parent/'pack'/'Day5')))
schema=json.loads((ROOT/'Day5_Grading/question_schema.json').read_text());source=(BASE/'experiments.py').read_text();marks=list(re.finditer(r'^# Q (\d+\.\d+)\s*$',source,re.M));prefix=source[:marks[0].start()];blocks={}
for i,m in enumerate(marks):blocks[m[1]]=source[m.end():marks[i+1].start() if i+1<len(marks) else source.index('# FINAL')].strip()
concepts={}
for line in (BASE/'concepts.txt').read_text().splitlines():
 q,i,reason=line.split('|',2);concepts[q]={'option_index':int(i),'reason':reason}
nb=nbformat.v4.new_notebook();cells=[nbformat.v4.new_markdown_cell('<div dir="rtl"><h1>تکلیف پنجم — پاسخ و اجرای واقعی ۱۴۴ زیرسؤال</h1><p>مدل‌های Q4 و Q8 واقعاً با llama.cpp و HTTP محلی اجرا می‌شوند. صف و KV شبیه‌سازی و آموزش adapter فقط روی لایهٔ خطی است. معیارهای خصوصی test تخمین زده نمی‌شوند.</p></div>'),nbformat.v4.new_code_cell(prefix)]
for section in schema:
 for q in section['questions']:
  qid=q['id'];cells.append(nbformat.v4.new_markdown_cell('<div dir="rtl"><h2>زیرسؤال '+qid+'</h2><p>'+q['prompt']+'</p></div>'))
  if qid in concepts:
   c=concepts[qid];option=q['fields'][0]['options'][c['option_index']-1];cell="answer = "+repr({'question_id':qid,'option_index':c['option_index'],'option':option})+"\nprint(json.dumps(answer,ensure_ascii=False,indent=2))";reason=c['reason']
  else:cell=blocks[qid];reason='تحلیل تفصیلی این زیرسؤال در گزارش پاسخ و در نسخهٔ نهایی همین سلول پس از اجرای کامل ثبت می‌شود؛ خروجی واقعی در سلول بالا حفظ شده است.'
  cells.append(nbformat.v4.new_code_cell(cell));cells.append(nbformat.v4.new_markdown_cell('<div dir="rtl"><b>تحلیل فارسی</b><p>'+reason+'</p></div>'))
cells.append(nbformat.v4.new_code_cell(source[source.index('# FINAL')+len('# FINAL'):].strip()))
nb.cells=cells;nb.metadata.kernelspec={'name':'python3','display_name':'Python 3','language':'python'};nb.metadata.language_info={'name':'python'}
nbformat.write(nb,BASE/'Day5_Executed.ipynb')
print('Notebook prepared:',len(cells),'cells; 96 actual practical code blocks.')
