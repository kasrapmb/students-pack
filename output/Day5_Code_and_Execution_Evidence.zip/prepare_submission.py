from pathlib import Path
import json,re,base64,zipfile,hashlib,platform,importlib.metadata,nbformat
BASE=Path(__file__).resolve().parent;OUT=BASE/'Day5_Run_Output';ROOT=BASE.parent/'pack'/'Day5'
S=json.loads((ROOT/'Day5_Grading/question_schema.json').read_text());R=json.loads((OUT/'answers_practical.json').read_text());assert len(R)==96
A={line.split('|',1)[0]:line.split('|',1)[1] for line in (BASE/'analyses.txt').read_text().splitlines()};C={}
for line in (BASE/'concepts.txt').read_text().splitlines():
 q,index,reason=line.split('|',2);C[q]={'option_index':int(index),'reason':reason}
source=(BASE/'experiments.py').read_text();marks=list(re.finditer(r'^# Q (\d+\.\d+)\s*$',source,re.M));blocks={}
for i,m in enumerate(marks):blocks[m[1]]=source[m.end():marks[i+1].start() if i+1<len(marks) else source.index('# FINAL')].strip()
def stringify(v):
 if v is True:return 'بله'
 if v is False:return 'خیر'
 if v is None:return 'null'
 if isinstance(v,(list,tuple)):return '، '.join(map(stringify,v))
 if isinstance(v,dict):return json.dumps(v,ensure_ascii=False)
 if isinstance(v,float):
  if v==int(v):return str(int(v))
  return format(v,'.17f').rstrip('0').rstrip('.')
 return str(v).replace('\n','؛ ')
form=[]
for section in S:
 for q in section['questions']:
  qid=q['id'];fields=q['fields'];values=[]
  if qid in C:
   c=C[qid];option=fields[0]['options'][c['option_index']-1];reason=c['reason']+'\nکد انتخاب: گزینهٔ '+str(c['option_index'])+' در ترتیب گزینه‌های همین صورت سؤال. این شماره کد مرجع خصوصی نیست.'
   values=[option,reason]
  else:
   result=R[qid];direct=list(result.values())[:len(fields)-1]
   if qid=='5.12':direct[1]=2
   if qid=='6.10':direct[2]=len(result['outside_capacity_volumes'])
   if qid=='7.12':direct[1]=len(result['required_evaluations'])
   if qid=='8.4':direct[1]=1
   assert len(direct)==len(fields)-1,qid
   method=A[qid]
   if qid=='5.12':method+=' این فیلد در schema از نوع عددی است؛ مقدار2 شمار variantهای واقعی برنامه‌ریزی‌شده است. نام و revision کامل هر دو در provenance و خروجی زیر ثبت است.'
   if qid=='6.10':method+=' فیلد عددی حجم خارج ظرفیت، تعداد سناریوهای حجمی ناممکن=2 را می‌دهد؛ حجم‌های دقیق100000 و1000000 درخواست در خروجی زیر آمده‌اند.'
   if qid=='7.12':method+=' فیلد عددی ارزیابی‌های لازم، شمار4 دسته را می‌گیرد و نام هر چهار دسته در خروجی ذکر شده است.'
   if qid=='8.4':method+=' فیلد عددی مدل فهرست‌شده شمار مدل=1 است؛ شناسهٔ دقیق مدل واقعی در خروجی زیر حفظ شده است.'
   method+='\n\nکد انگلیسی اجراشده برای همین زیرسؤال (توابع مشترک در Day5_Code/local_lab.py و سلول راه‌اندازی نوت‌بوک):\n'+blocks[qid]
   method+='\n\nخروجی واقعی همین اجرا:\n'+json.dumps(result,ensure_ascii=False,indent=2)
   method+='\n\nشواهد: نوت‌بوک اجراشده، گزارش‌های Day5_Run_Output و README بازاجرا در ZIP پیوست. معیار خصوصی test در هیچ مرحله تخمین زده نشده است.'
   values=[*direct,method]
  assert len(values)==len(fields),(qid,len(values),len(fields))
  entries=[]
  for i,(field,value) in enumerate(zip(fields,values)):
   text=value if field['kind']=='textarea' else stringify(value)
   if field['kind']=='choice':assert text in field['options'],(qid,text,field['options'])
   if field['kind']=='number':assert not isinstance(value,(list,dict,str,bool)),(qid,field['label'],value)
   entries.append({'index':i,'label':field['label'],'kind':field['kind'],'value':text,'option_index':field.get('options',[]).index(text) if field['kind']=='choice' else None})
  form.append({'id':qid,'fields':entries})
(BASE/'form_answers.json').write_text(json.dumps(form,ensure_ascii=False,indent=2))
# Only replace analysis markdown; retain the actual executed code and outputs.
nb=nbformat.read(BASE/'Day5_Executed.ipynb',as_version=4);images={'5.9':'active_ratios.png','6.6':'capacity.png','6.10':'cost_with_capacity.png','7.7':'quant_groups.png','8.5':'tokenizer.png','9.3':'language_accuracy.png','9.8':'latency_ecdf.png','10.5':'queue_latency.png','10.7':'block_waste.png','11.6':'adapter_rank2.png'}
for index,question in enumerate(form):
 q=question['id'];cell=nb.cells[2+3*index+2];reason=C[q]['reason'] if q in C else A[q]
 cell.source='<div dir="rtl"><b>تحلیل فارسی زیرسؤال '+q+'</b><p>'+reason+'</p></div>'
 if q in images:
  name=images[q];cell.source+='\n\n![نمودار واقعی آزمایش '+q+'](attachment:'+name+')';cell.attachments={name:{'image/png':base64.b64encode((OUT/name).read_bytes()).decode()}}
errors=[o for c in nb.cells if c.cell_type=='code' for o in c.outputs if o.output_type=='error'];assert not errors
assert all(c.execution_count is not None for c in nb.cells if c.cell_type=='code')
nbformat.write(nb,BASE/'Day5_Executed.ipynb')
requirements=['numpy','pandas','matplotlib','requests','nbformat','nbclient','ipykernel']
(BASE/'requirements-executed.txt').write_text('\n'.join(f'{name}=={importlib.metadata.version(name)}' for name in requirements)+'\n')
summary={'questions':len(form),'practical':len(R),'executed_code_cells':sum(c.cell_type=='code' for c in nb.cells),'notebook_errors':len(errors),'checker_passed':R['12.11']['checker_passed'],'checker_checks':R['12.11']['checker_checks'],'longest_answer_characters':max(len(f['value']) for q in form for f in q['fields']),'Python':platform.python_version(),'quant':R['9.4']['selected_quant'],'HR_action_accuracy':R['12.4']['action_accuracy'],'HR_grounded':R['12.6']['grounded']}
(OUT/'submission_validation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
